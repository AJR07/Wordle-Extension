# Corrodle

An extension to help u get your wordle correct!
